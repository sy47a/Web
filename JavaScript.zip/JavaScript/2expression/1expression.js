let b;
b = 2;

let a = b = 2;
console.log(a);