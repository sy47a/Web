let a = 5;
a = -a;
console.log(a);
a = -a;
console.log(a);
a = +a;
console.log(a);

let boolean = true;
console.log(boolean);
console.log(!boolean);

console.clear();
console.log(+false);
console.log(+null);
console.log(+'');
console.log(+true);