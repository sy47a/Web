let text = "두개의" + "문자"
console.log(text);
text = '1' + 1;
console.log(text);
add = 1 + 1;
console.log(add);