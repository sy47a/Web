let a = 1;
a = a + 2;
console.log(a);

a += 2;
console.log(a);