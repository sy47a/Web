let a = 0;
console.log(a);
a++; // a = a + 1;
console.log(a);
a--; // a = a - 1;
console.log(a);

a = 0;
let b = a++;
console.log(b);
console.log(a);
let c = ++a;
console.log(c);
console.log(a);