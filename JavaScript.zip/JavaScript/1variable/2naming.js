let integer = 123; //정수
let negative = -123; //음수
let double = 1.23; //실수

let binary = 0b1111011; //2진수
